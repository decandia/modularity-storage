#ifndef __SYSTEM_H__
#define __SYSTEM_H__

int systemf(int flag,const char *format,...);
int filexist(const char *format,...);

#ifndef __HEADERS__
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#define __HEADERS__
#include "debug.c"

int systemf(int flag,const char *format,...)
  {
   char buffer[PATH_MAX];
   va_list ap;
   va_start(ap,format);
   vsprintf(buffer,format,ap);
   va_end(ap);
   if (flag) debug(0,"%s\n",buffer);
   int err=system(buffer);
   if (err!=0)
     {
     }
   return err;
  }

int filexist(const char *format,...)
  {
   char buffer[PATH_MAX];
   va_list ap;
   va_start(ap,format);
   vsprintf(buffer,format,ap);
   va_end(ap);
   struct stat buf;                             
   int err2=lstat(buffer,&buf);
   if (err2==-1)
     {
      return 0;
     }
   else
     {
      if (S_ISREG(buf.st_mode)) return 1;
      else if (S_ISDIR(buf.st_mode)) return 2;
      else return 15;
     }
  }
#endif
#endif
