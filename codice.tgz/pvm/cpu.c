#ifndef __CPU_H__
#define __CPU_H__
#include <stdlib.h>

void cpustart(double cpu=0.);
double cputime(double *stime=NULL);
double walltime(void);
int cpuint(int level=0,int nmax=0);
int cputerm(void);

#ifndef __HEADERS__
#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#define __HEADERS__
#include "system.c"

static int init_cpu;
static double cpu;		
static double save;		
static double start;		
static double last;		
static int flag;		
static double ctrc;		
static double flast;		

const double smin=900./256;		
const double smax=899;			

#define lmax 16
static int ftmp[lmax];

#define TBIG 1e30

static void handler(int signum)
  {
   if (signum==SIGTERM)
     {
      flag=1;
     }
   else if (signum==SIGINT)
     {
      double now=walltime();
      if (ctrc<TBIG && now<ctrc+1)
        {
         ctrc=TBIG;
         flag=1;	
        }
      else ctrc=now;		
     }
   signal(signum,handler);
  }

double cputime(double *_stime)
  {
   struct rusage usage;
   if (getrusage(RUSAGE_SELF,&usage))
     {
      fprintf(stderr,"cputime: errore in getrusage\n");
      exit(1);
     }
   double utime=(double)usage.ru_utime.tv_sec+1e-6*(double)usage.ru_utime.tv_usec;		
   double stime=(double)usage.ru_stime.tv_sec+1e-6*(double)usage.ru_stime.tv_usec;		
   if (_stime) *_stime=stime;
   return utime+stime;
  }

double walltime(void)
  {
   if (init_cpu==0) cpustart(0.);
   struct timespec tp;
   clock_gettime(CLOCK_MONOTONIC_RAW,&tp);
   return (double)tp.tv_sec+1e-9*(double)tp.tv_nsec-start;
  }

void cpustart(double _cpu)
  {
   init_cpu++;						
   if (_cpu>0) cpu=_cpu;
   if (init_cpu==1) start=walltime();
   signal(SIGINT,handler);
   signal(SIGTERM,handler);
   ctrc=TBIG;
   save=smin;
  }

int cpuint(int level,int nmax)		
  {
   static long nhit;
   if (nmax>0)
     {
      nhit++;
      if (nhit%nmax) return 0;
     }
   int flag2=(level==0?flag:0);
   double now=walltime();
   if (now>ctrc+1)
     {
      ctrc=TBIG;
      last=now;
      flag2=1;
     }
   else if (save>0 && now>last+save) 
     {
      if (save<smax) save*=2;
      last=now;
      flag2=1;
     }
   int fret=ftmp[level];
   if (flag2)
     {
      for (int l=0;l<level;l++) ftmp[l]=1;
      fret=1;
     }
   else ftmp[level]=0;
   return fret;
  }

int cputerm(void)
  {
   double now=walltime();
   if (now-flast>30)
     {
      flast=now;
      if (filexist("STOP")) return 1;
     }
   if (cpu>0 && now>cpu) return 1; else return flag;
  }
#endif
#endif
