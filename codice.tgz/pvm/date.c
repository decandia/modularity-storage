#ifndef __DATE_H__
#define __DATE_H__
#include <stdlib.h>

char *date(char *buffer=NULL);
char *estimatedtime(double etc);

#ifndef __HEADERS__
#include <stdio.h>
#include <time.h>
#include <string.h>
#define __HEADERS__
#include "cpu.c"

char *date(char *buffer)
  {
   static char buff[64];
   time_t t;
   struct tm *tm;
   t=time(NULL);
   tm=localtime(&t);
   strftime(buff,24,"%a %b %d %H:%M %Y",tm);
   if (buffer)
     {
      strcpy(buffer,buff);
      return buffer;
     }
   else return buff;
  }

#define BS1  	200
#define BS2	300

char *estimatedtime(double etc)
  {
   static char buffer[BS1],buffer2[BS2];
   double now=time(NULL);
   double tend=now+etc;
   if (etc<60) sprintf(buffer,"%.2f secondi",etc);
   else if (etc<3600) sprintf(buffer,"%.2f minuti",etc/60);
   else if (etc<86400) sprintf(buffer,"%.2f ore",etc/3600);
   else if (etc<30*86400) sprintf(buffer,"%.2f giorni",etc/86400);
   else if (tend<(double)(1L<<32))		
     {
      time_t t=(time_t)tend;
      struct tm *tm=localtime(&t);
      strftime(buffer,BS1,"%b %d %Y",tm);
     }
   else sprintf(buffer,"%.3g anni",etc/(365.25*86400));
   if (cputerm()) sprintf(buffer2,"%20s (tempo esaurito)",buffer); else strcpy(buffer2,buffer);
   return buffer2;
  }
#endif
#endif
