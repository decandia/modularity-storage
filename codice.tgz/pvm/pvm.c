#ifndef __PVM_H__
#define __PVM_H__
#include <stdlib.h>

void pvm_init(int *argc=NULL,char ***argv=NULL);
void pvm_end(void);
int pvm_mype(void);
int pvm_debug(void);
int ntabs(int k,...);
int pvm_endjob(void);

#ifndef __HEADERS__
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <sys/types.h>
#include <stdarg.h>
#define __HEADERS__
#include "debug.c"
#include "mpi.c"
#include "random.c"
#include "cpu.c"
#include "getmem.c"
#include "fopenf.c"
#include "getarg.c"
#include "date.c"
#include "next.c"

static int mype;
static int npes=1;
static int mype2;	
static int npes2=1;	
static int flag=1;	
static int chdr;	

void pvm_init(int *argc,char ***argv)
  {
   mpi_init(argc,argv);
   init_args(argc,argv);

   flag=getarg_i("#debug",1);
   if (flag==0) args_out("getarg.log");

   mype=getarg_i("#mype",0);
   npes=getarg_i("#npes",1);
   mype2=mpi_mype();
   npes2=mpi_npes();

   int off=mype*npes2+mype2;
   char *root=getarg_s("#root");
   if (root)
     {
      if (chdir(root)) debug(9,"pvm: errore in chdir(\"%s\")...\n",root);
     }
   else if (flag==0 || npes>1 || npes2>1)
     {
      char buffer[PATH_MAX];
      sprintf(buffer,"RUN/%03i/",off);
      makedir(buffer);
      if (chdir(buffer)) debug(9,"pvm: errore in chdir(\"%s\")...\n",buffer);
     }

   char *path=getarg_s("#stdout");
   if (flag==0 && path==NULL)
     {
      path=(char*)realloc(path,24*sizeof(char));
      strcpy(path,"mpirun.log");
     }
   if (path)
     {
      makedir(path);
      if (freopen(path,"a",stdout)==NULL) debug(9,"pvm: errore in freopenf(%s)\n",path);
      if (dup2(STDOUT_FILENO,STDERR_FILENO)==-1) debug(9,"pvm: errore in dup2\n");
     }
   setlinebuf(stdout);
   int mypid=getpid();
   int seed=getarg_i("#seed",(int)time(NULL));
   int seed2=getarg_i("#seed2",off);
   init_random(seed,seed2);

   double cpu=getarg_d("#cpu",0.);
   cpustart(cpu);
   init_next();
   debug(0,"seed=%i\n",seed);
   debug(0,"seed2=%i\n",seed2);
   if (flag==0)
     {
      FILE *stream=fopen("pvm.log","a");
      fprintf(stream,"pvm_init: %s (%g) pid=%i\n",date(),cputot(),mypid);
      fclose(stream);
     }
  }

int pvm_mype(void) {return mype;}
int pvm_debug(void) {return flag;}				

int ntabs(int k,...)
  {
   int n=mype;
   va_list ap;
   va_start(ap,k);
   for (int i=1;i<=k;i++)
     {
      int m=va_arg(ap,int);
      if (i<k) n=n/m; else n=n%m;
     }
   va_end(ap);
   return n;
  }

void pvm_end(void)
  {
   if (flag==0)
     {
      FILE *stream=fopen("pvm.log","a");
      fprintf(stream,"pvm_end: %s (%g)\n",date(),cputot());
      fclose(stream);
     }
   mpi_end();
   exit(EXIT_SUCCESS);
  }

int pvm_endjob(void)
  {
   int flag2=getarg_i("#endjob",0);
   return flag2;
  }
#endif
#endif
