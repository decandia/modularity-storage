#ifndef __NEXT_H__
#define __NEXT_H__

void init_next(void);
double cputot();
int fnext(void);
int nfile(void);
int filemin(double ftmp=0.333334);
int filemax(double ftmp=1);
int cpunext(int mpi=0);
int cpustop(int mpi=0);
void mpierror(int err,const char *format,...);

#ifndef __HEADERS__
#include <stdio.h>
#include <math.h>
#include <stdarg.h>
#define __HEADERS__
#include "pvm.c"
#include "cpu.c"
#include "debug.c"
#include "mpi.c"
#include "fopenf.c"

static int init;
static int mype;
static int npes;
static double start;
static double tmin;
static double tmax;
static double delta;
static double tnext;
static int flag;
static int n;
static int m;
static long count;

void init_next(void)
  {
   tmin=3600./1024.;
   tmax=3600;
   delta=tmin;
   tnext=delta;
   flag=0;
   n=0;
   start=0;
   count=0;
   FILE *stream=fopenf("temp/NEXT","r");
   if (stream)
     {
      int err=0;
      err!=(fscanf(stream,"%i",&n)!=1);
      double ytmp;
      err!=(fscanf(stream,"%le",&ytmp)!=1);
      err!=(fscanf(stream,"%li",&count)!=1);
      fclose(stream);
      start=ytmp;
     }
   double eps=0.001;
   while (tnext<start+eps)		
     {
      if (delta<tmax) delta*=2;
      tnext+=delta;
     }
   mype=mpi_mype();
   npes=mpi_npes();
   init=1;
  }

double cputot(void)
  {
   if (init==0) init_next();
   return rint(start+walltime());
  }

int cpunext(int mpi)
  {
   count++;
   if (init==0) init_next();
   int flag2=0;
   if (mpi==0 || mype==0)			
     {
      flag2=cpuint(0);
      double now=start+walltime();
      if (now>tnext)
        {
         flag=1;
         flag2|=flag;
        }
     }
   if (mpi)
     {
      mpi_ibcast(&flag,1,0);
      mpi_ibcast(&flag2,1,0);
     }
   if (flag)
     {
      if (m>0) debug(9,"errore: fnext() non chiamata all'interno del ciclo di cpunext()...\n");
      m++;
     }
   else m=0;
   return flag2;
  }

int fnext(void)					
  {						
   int flag2=flag;
   if (flag)
     {
      n++;
      if (pvm_debug()==0)
        {
         FILE *stream=fopenf("temp/NEXT","w");
         fprintf(stream,"%i\n",n);
         fprintf(stream,"%.3f\n",tnext);
         fprintf(stream,"%li\n",count);
         fclose(stream);
        }
      if (delta<tmax) delta*=2;
      tnext+=delta;
      flag=0;
      m=0;
     }
   return flag2;
  }

int nfile(void)
  {
   return n;
  }

int filemax(double ftmp)
  {
   int nmax=(int)rint(ftmp*n);
   FILE *stream=fopen("NMAX","r");
   if (stream)
     {
      if (fscanf(stream,"%i",&nmax));
      fclose(stream);
     }
   return nmax;
  }

int filemin(double ftmp)
  {
   int nmin=(int)floor(ftmp*n);
   FILE *stream=fopen("NMIN","r");
   if (stream)
     {
      if (fscanf(stream,"%i",&nmin));
      fclose(stream);
     }
   return nmin;
  }

int cpustop(int mpi)
  {
   if (init==0) init_next();
   int flag2=0;
   if (mpi==0 || mype==0) flag2=cputerm();
   if (mpi) mpi_ibcast(&flag2,1,0);
   return flag2;
  }

void mpierror(int err,const char *format,...)	
  {
   if (init==0) init_next();
   if (err)
     {
      fprintf(stderr,"mype=%i/%i, error %i, ",mype,npes,err);
      va_list ap;
      va_start(ap,format);
      vfprintf(stderr,format,ap);
      va_end(ap);
     }
   int flag2=err;
   if (mype==0)
     {
      int flag3;
      for (int i=1;i<npes;i++)
        {
         mpi_irecv(&flag3,1,i);
         flag2|=flag3;
        }
     }
   else mpi_isend(&flag2,1,0);
   mpi_ibcast(&flag2,1,0);
   if (flag2) exit(1);
  }
#endif
#endif
