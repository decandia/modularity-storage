#ifndef __DEBUG_H__
#define __DEBUG_H__

void block_debug(int level);
void debug(int level,const char *format,...);
void dopenf(int level,const char *format,const char *mode,...);
void dclose(int level);

#ifndef __HEADERS__
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#define __HEADERS__
#include "getmem.c"
#include "fopenf.c"

static int init;
static int lmax=10;
static FILE **fout;

static void init_debug(void)
  {
   fout=(FILE**)getmem(NULL,lmax*sizeof(FILE*));
   for (int l=0;l<lmax;l++) if (l%8) fout[l]=stderr; else fout[l]=stdout;
   init=1;
  }

static int block;
void block_debug(int level) {block=level;}

void dopenf(int level,const char *format,const char *mode,...)
  {
   if (level<0 || level>=lmax) debug(9,"debug: level=%i\n",level);
   if ((level&block)==0)
     {
      if (init==0) init_debug();
      va_list ap;
      va_start(ap,mode);
      fout[level]=vfopenf(format,mode,ap);
      va_end(ap);
     }
  }

void dclose(int level)
  {
   if (level<0 || level>=lmax) debug(9,"debug: level=%i\n",level);
   if ((level&block)==0)
     {
      fclose(fout[level]);
      fout[level]=stderr;
     }
  }

void debug(int level,const char *format,...)
  {
   if (level<0 || level>=lmax) debug(9,"debug: level=%i\n",level);
   if (init==0) init_debug();
   if (level&8 || (level&block)==0)
     {
      va_list ap;
      va_start(ap,format);
      vfprintf(fout[level],format,ap);
      va_end(ap);
      if (level&8) exit(1);
     }
  }
#endif
#endif
