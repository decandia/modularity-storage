#ifndef __READ_H__
#define __READ_H__
#include <stdio.h>

void readline(void *A,int N,FILE *stream,int type);
void writeline(void *A,int N,FILE *stream,int type);

#ifndef __HEADERS__
#define __HEADERS__
#include <stdlib.h>
#include "debug.c"
#include "buff.c"

void readline(void *A,int N,FILE *stream,int type)
  {
   if (bufread(stream)==NULL) debug(9,"readline: errore nella lettura del file...\n");
   for (int i=0;i<N;i++)
     {
      char *p=nextok();
      if (*p=='\0') debug(9,"readline: errore nella lettura del file...\n");
      if (type) sscanf(p,"%le",&(((double*)A)[i])); else sscanf(p,"%i",&(((int*)A)[i]));
     }
  }

void writeline(void *A,int N,FILE *stream,int type)
  {
   for (int i=0;i<N;i++) if (type) fprintf(stream," %g",((double*)A)[i]); else fprintf(stream," %i",((int*)A)[i]);
   fprintf(stream,"\n");
  }

#endif
#endif
