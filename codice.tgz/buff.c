#ifndef __BUFF_H__
#define __BUFF_H__
#include <stdio.h>

char *bufread(FILE *stream);
char *nextok(void);

#ifndef __HEADERS__
#include <string.h>
#include <ctype.h>
#define __HEADERS__
#include "debug.c"
#include "getmem.c"

#define BUF_SIZE 4096

static int size;
static char *buffer;
static int n;
static int q;

char *bufread(FILE *stream)
  {
   n=0;					
   char buff[BUF_SIZE];
   while (1)
     {
      if (size<n+BUF_SIZE)
        {
         size+=BUF_SIZE;
         buffer=(char*)getmem(buffer,size*sizeof(char));
        }
      if (fgets(buff,BUF_SIZE,stream)==NULL) break;
      int m=strlen(buff);
      memcpy(buffer+n,buff,m);		
      if (buffer[n+m-1]=='\n')
        {
         n+=m-1;
         buffer[n]='\0';
         break;
        }
      else n+=m;
     }
   if (n>=size || buffer[n]!='\0') debug(9,"errore in bufread...\n");
   q=0;
   return buffer;
  }

char *nextok(void)
  {
   if (q<n)
     {
      while (isspace(buffer[q])) q++;
      if (q==n) return buffer+n;
      int p=q;
      while (isgraph(buffer[q])) q++;
      buffer[q]='\0';
      if (q<n) q++;
      return buffer+p;
     }
   else return buffer+n;
  }
#endif
#endif
